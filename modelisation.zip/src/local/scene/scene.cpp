

#include <GL/glew.h>

#include "scene.hpp"

#include "../../lib/opengl/glutils.hpp"
#include "../../lib/perlin/perlin.hpp"
#include "../../lib/interface/camera_matrices.hpp"
#include "../interface/myWidgetGL.hpp"
#include "../../lib/mesh/mesh_io.hpp"

#include <cmath>
#include <string>
#include <sstream>

#include <iostream>
#include <algorithm>
#include <stdlib.h>

#define PI 3.1415

using namespace cpe;

namespace perso{
    template<typename T>
    T abs(T t){
        if(t < 0){
            return (-1) * t;
        }
        else{
            return t;
        }
    }
}

void applatir(float x, float y, float &z, float space){
    float width = 0.1f;
    float height = 0.6f;

    float xcenter = 0;
    float ycenter = 0;

    float dx = std::max(perso::abs(x - xcenter) - width / 2, 0.f);
    float dy = std::max(perso::abs(y - ycenter) - height / 2, 0.f);

    float distance = dx * dx + dy * dy;

    if(distance <= space)
        z *= cos((space - distance) / space * PI / 2);
}

mesh create_terrain(int xmin, int xmax, int ymin, int ymax, int Nu, int Nv){
    mesh m;

    float x, y, z;
    perlin p(10, 0.2f);

    for(int kv = 0; kv < Nv; ++kv){
        for(int ku = 0; ku < Nu; ++ku){
            x = xmin + (ku * (float)(xmax - xmin) / Nu);
            y = ymin + (kv * (float)(ymax - ymin) / Nv);
            z = p(vec2(x, y));

            applatir(x, y, z, 0.1f);

            m.add_vertex( {x, y, z / 4.f} );
            m.add_texture_coord( vec2((float)ku / (float)Nu, (float)kv / (float)Nv) );
        }
    }

    for(int kv = 0; kv < Nv - 1; ++kv){
        for(int ku = 0; ku < Nu - 1; ++ku){
            m.add_triangle_index( {ku + Nu * kv, ku + 1 + Nu * kv, ku + 1 + Nu * (kv + 1)} );
            m.add_triangle_index( {ku + Nu * kv, ku + Nu * (kv + 1), ku + 1 + Nu * (kv + 1)} );
        }
    }



    m.fill_empty_field_by_default();

    m.transform_apply_rotation({1.0f,0.0f,0.0f},-M_PI/2.0f);

    return m;
}

mesh create_tour(float x_centre, float y_centre, float z_centre, float h, float r, int N){
    mesh m;

    float x, y, z;

    for(int i = 0; i < N; ++i){
        x = x_centre + r * cos(2 * M_PI * (float)i / N);
        y = y_centre + r * sin(2 * M_PI * (float)i / N);

        z = z_centre;

        m.add_vertex( {x, y, z - (float)h / 2.f} );
        m.add_vertex( {x, y, z + (float)h / 2.f} );

        m.add_texture_coord( vec2( (float)i / N, 0 ) );
        m.add_texture_coord( vec2( (float)i / N, 1 ) );
    }

    for(int i = 0; i < 2 * N - 2; ++i){
        m.add_triangle_index( {i, i + 1, i + 2});
    }
    m.add_triangle_index( {2 * N - 2, 2 * N - 1, 0} );
    m.add_triangle_index( {0, 2 * N - 1, 1} );

    m.fill_empty_field_by_default();
    m.transform_apply_rotation( {1.0f, 0.0f, 0.0f}, -M_PI / 2.0f );

    return m;
}


void scene::load_scene()
{

    //*****************************************//
    // Preload default structure               //
    //*****************************************//
    texture_default = load_texture_file("data/white.jpg");
    shader_program_id = read_shader("shaders/shader_mesh.vert",
                                    "shaders/shader_mesh.frag"); PRINT_OPENGL_ERROR();


    //*****************************************//
    // OBJ Mesh                                //
    //*****************************************//
    texture_dinosaur=load_texture_file("data/stegosaurus.jpg");
    mesh_dinosaur=load_mesh_file("data/stegosaurus.obj");
    mesh_dinosaur.transform_apply_auto_scale_and_center();
    mesh_dinosaur_opengl.fill_vbo(mesh_dinosaur);

    //*****************************************//
    // OFF Mesh                                //
    //*****************************************//
    mesh_camel=load_mesh_file("data/camel.off");
    mesh_camel.transform_apply_auto_scale_and_center();
    mesh_camel.transform_apply_scale(0.5f);
    mesh_camel.transform_apply_rotation({1.0f,0.0f,0.0f},-M_PI/2.0f);
    mesh_camel.transform_apply_rotation({0.0f,1.0f,0.0f}, 5*M_PI/6.0f);
    mesh_camel.transform_apply_translation({-0.55f,-0.0f,0.1f});
    mesh_camel.fill_color_xyz();
    mesh_camel_opengl.fill_vbo(mesh_camel);

    //*****************************************//
    // Generate piste att mesh                 //
    //*****************************************//
    texture_ground = load_texture_file( "data/landing.jpg" );

    mesh_ground.add_vertex( {-0.05f, 0.001f,-0.3f} );
    mesh_ground.add_texture_coord( vec2(0.f, 0.f) );
    mesh_ground.add_vertex( {-0.05f, 0.001f, 0.3f} );
    mesh_ground.add_texture_coord( vec2(0.f, 1.f) );
    mesh_ground.add_vertex( { 0.05f, 0.0001f, 0.3f} );
    mesh_ground.add_texture_coord( vec2(1.f, 1.f) );
    mesh_ground.add_vertex( { 0.05f, 0.0001f,-0.3f} );
    mesh_ground.add_texture_coord( vec2(1.f, 0.f) );

    mesh_ground.add_triangle_index({0,2,1});
    mesh_ground.add_triangle_index({0,3,2});

    mesh_ground.fill_empty_field_by_default();

    mesh_ground_opengl.fill_vbo(mesh_ground);

    //*****************************************//
    // Generate patoizeau defined mesh         //
    //*****************************************//
    const int Nu = 500;
    const int Nv = 500;

    texture_ptz = load_texture_file( "data/grass.jpg" );
    mesh_ptz = create_terrain(-1, 1, -1, 1, Nu, Nv);
    mesh_ptz_opengl.fill_vbo(mesh_ptz);

    //*****************************************//
    // Generate tour defined mesh              //
    //*****************************************//
    float x_centre = 0.1f;
    float y_centre = 0.3f;
    float z_centre = 0.15f;
    float h = 0.3f;
    float r = 0.04f;
    int N = 100;

    texture_tour = load_texture_file( "data/tour.jpg" );
    mesh_tour = create_tour(x_centre, y_centre, z_centre, h, r, N);
    mesh_tour_opengl.fill_vbo(mesh_tour);
}

void scene::draw_scene()
{
    //Setup uniform parameters
    glUseProgram(shader_program_id);                                                                           PRINT_OPENGL_ERROR();

    //Get cameras parameters (modelview,projection,normal).
    camera_matrices const& cam=pwidget->camera();

    //Set Uniform data to GPU
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"camera_modelview"),1,false,cam.modelview.pointer());     PRINT_OPENGL_ERROR();
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"camera_projection"),1,false,cam.projection.pointer());   PRINT_OPENGL_ERROR();
    glUniformMatrix4fv(get_uni_loc(shader_program_id,"normal_matrix"),1,false,cam.normal.pointer());           PRINT_OPENGL_ERROR();

    /*
    //Draw the meshes
    glBindTexture(GL_TEXTURE_2D,texture_dinosaur); PRINT_OPENGL_ERROR();
    mesh_dinosaur_opengl.draw();

    glBindTexture(GL_TEXTURE_2D,texture_default);  PRINT_OPENGL_ERROR();
    mesh_camel_opengl.draw();
    */

    //Draw ground's mesh
    glBindTexture(GL_TEXTURE_2D, texture_ground); PRINT_OPENGL_ERROR();
    mesh_ground_opengl.draw();

    //Draw patoizeau's mesh
    glBindTexture(GL_TEXTURE_2D, texture_ptz); PRINT_OPENGL_ERROR();
    mesh_ptz_opengl.draw();

    //Draw tour's mesh
    glBindTexture(GL_TEXTURE_2D, texture_tour); PRINT_OPENGL_ERROR();
    mesh_tour_opengl.draw();

}


scene::scene()
    :shader_program_id(0)
{}


GLuint scene::load_texture_file(std::string const& filename)
{
    return pwidget->load_texture_file(filename);
}

void scene::set_widget(myWidgetGL* widget_param)
{
    pwidget=widget_param;
}


